/**
 * We will use this to determine
 * whether a reward has been unlocked or not
 *
 * Anthony Contestabile
 */

public enum rewardStatus {
    locked, unlocked
}
